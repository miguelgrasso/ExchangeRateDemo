package com.demo.exchangeRate.security.service;


import com.demo.exchangeRate.security.dto.AuditlogDto;
import com.demo.exchangeRate.security.entity.Auditlog;
import com.demo.exchangeRate.security.entity.User;
import com.demo.exchangeRate.security.jwt.JwtProvider;
import com.demo.exchangeRate.security.repository.AuditlogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@Service
@Slf4j
@RequiredArgsConstructor
public class AuditlogService {

    private final AuditlogRepository auditlogRepository;

    private final JwtProvider jwtProvider;
        public Mono<Auditlog> save(AuditlogDto auditlogDto) {

            return auditlogRepository.save(Auditlog.builder()
                        .username(auditlogDto.getUsername())
                        .method(auditlogDto.getMethod())
                        .uri(auditlogDto.getUri())
                        .status(auditlogDto.getStatus())
                        .dateTransaction(LocalDateTime.now())
                .build());
    }

    public Flux<Auditlog> getAll() {
        return auditlogRepository.findAll();
    }

}
