package com.demo.exchangeRate.security.config;

import com.demo.exchangeRate.security.dto.AuditlogDto;
import com.demo.exchangeRate.security.jwt.JwtFilter;
import com.demo.exchangeRate.security.jwt.JwtProvider;
import com.demo.exchangeRate.security.repository.SecurityContextRepository;
import com.demo.exchangeRate.security.service.AuditlogService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

@EnableWebFluxSecurity
@EnableReactiveMethodSecurity
@RequiredArgsConstructor
public class MainSecurity implements WebFilter {

    private final SecurityContextRepository securityContextRepository;
    private final JwtProvider jwtProvider;
    private final AuditlogService auditlogService;

    @Bean
    public SecurityWebFilterChain filterChain(ServerHttpSecurity http, JwtFilter jwtFilter) {
        return http
                .authorizeExchange()
                .pathMatchers("/auth/**").permitAll()
                .anyExchange().authenticated()
                .and()
                .addFilterAfter(jwtFilter, SecurityWebFiltersOrder.FIRST)
                .securityContextRepository(securityContextRepository)
                .formLogin().disable()
                .logout().disable()
                .httpBasic().disable()
                .csrf().disable()
                .build();
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String token = exchange.getRequest().getHeaders().getFirst("Authorization");

        return chain.filter(exchange)
                .doOnSuccess(unused -> {
                    String method = exchange.getRequest().getMethodValue();
                    String uri = exchange.getRequest().getURI().toString();
                    int status = exchange.getResponse().getStatusCode().value();
                    System.out.println(method);
                    System.out.println(uri);
                    System.out.println(status);
                    /*Mono<CreateUserDto> dtoMono = request.bodyToMono(CreateUserDto.class).doOnNext(objectValidator::validate);
        return dtoMono
                .flatMap(dto -> ServerResponse.ok().contentType(MediaType.APPLICATION_JSON).body(userService.create(dto), User.class));*/
                    if(token != null )  {
                        String username = jwtProvider.getSubject(token.replace("Bearer ", ""));
                        AuditlogDto auditlogDto = new AuditlogDto();
                        auditlogDto.setMethod(method);
                        auditlogDto.setUri(uri);
                        auditlogDto.setStatus(status);
                        auditlogDto.setUsername(username);
                        System.out.println(method);
                        System.out.println(uri);
                        System.out.println(status);
                        System.out.println(username);
                        auditlogService.save(auditlogDto);
                    }
                });
    }


}
