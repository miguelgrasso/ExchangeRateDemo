package com.demo.exchangeRate.security.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class AuditlogDto {

    private String username;
    private String method;
    private String uri;
    private int status;
}
