package com.demo.exchangeRate.security.repository;

import com.demo.exchangeRate.security.entity.Auditlog;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditlogRepository extends ReactiveCrudRepository<Auditlog, Integer> {

}
