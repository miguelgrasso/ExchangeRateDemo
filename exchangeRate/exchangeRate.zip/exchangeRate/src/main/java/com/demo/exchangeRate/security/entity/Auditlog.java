package com.demo.exchangeRate.security.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import java.time.LocalDateTime;

@Table(name = "auditlog")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@Slf4j
public class Auditlog {
    @Id
    private int id;
    private String username;
    private String method;
    private String uri;
    private int status;
    private LocalDateTime dateTransaction;

}
