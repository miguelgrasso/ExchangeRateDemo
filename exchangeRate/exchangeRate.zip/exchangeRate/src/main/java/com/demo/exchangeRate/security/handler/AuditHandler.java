package com.demo.exchangeRate.security.handler;


import com.demo.exchangeRate.security.entity.Auditlog;
import com.demo.exchangeRate.security.entity.User;
import com.demo.exchangeRate.security.service.AuditlogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

@Component
@Slf4j
@RequiredArgsConstructor
public class AuditHandler {

    private final AuditlogService auditlogService;

    public Mono<ServerResponse> getAll(ServerRequest request) {
        return ServerResponse.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(auditlogService.getAll(), Auditlog.class);
    }
}
